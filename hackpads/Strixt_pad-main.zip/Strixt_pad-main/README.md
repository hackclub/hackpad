Hello Everyone! This is my custom macorpad! Fully designed with 12 switches all with the function of using as f keys (my keyboard doesn't have dedicated f keys LOL).

I was origrinally going with an 11 key design that also had a knob and an LCD screen, however, I realized my time constraints and had to just settle with 12 key macropad (poor time management skills came in clutch at the wrong moment!)

![image](https://github.com/user-attachments/assets/6b97f859-1c61-41c7-b0df-bf4033fa0465)

PARTS USED:
- SEEED Xiao 2040
- 12 mx switches
- 12 Diode-35 tht
