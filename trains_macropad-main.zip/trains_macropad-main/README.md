# trains_macropad
 first macropad!
This macropad is my first attempt at making one! I've included six inputs - four hotswap cherry MX sockets, two rotary encoders, with per-key RGB lighting _and_ an OLED screen to boot!
### Firmware
This is still a WIP.

# BOM:

    4x Cherry MX AntiShear Hotswap Sockets
    2x EC11 Encoder
    1x PCB
    6x Through-hole 1N4148 Diodes
    4x WS2812B LEDs
    1x 0.91" OLED screen
    1x PCF8574A IO expander board
    4x Gateron Milky Yellows
    4x keycaps
    1x case
    4x M3x7 screws
    1x 10k ohm resistor
